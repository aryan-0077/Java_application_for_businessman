-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2019 at 04:01 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oxy_login`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `gst_no` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `mobile_no` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`gst_no`, `name`, `address`, `mobile_no`) VALUES
('123456789', 'aryan', '26/3 , gandhi nagar', '7390913001');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `Bill_no` int(11) NOT NULL,
  `P_name` varchar(20) NOT NULL,
  `Qty` int(11) NOT NULL,
  `Price` int(11) NOT NULL,
  `Amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`Bill_no`, `P_name`, `Qty`, `Price`, `Amount`) VALUES
(1, 'Long Body', 2, 860, 1720),
(2, 'Long Body', 5, 860, 4300),
(2, 'Pillar Cock', 5, 880, 4400),
(2, 'Long Body', 2, 860, 1720),
(3, 'Long Body', 5, 860, 4300),
(3, 'Angular Stop Cock', 2, 760, 1520);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `Bill_no` int(11) NOT NULL,
  `Bill_date` date NOT NULL,
  `C_name` varchar(20) NOT NULL,
  `Mobile` varchar(10) NOT NULL,
  `Total_Amt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`Bill_no`, `Bill_date`, `C_name`, `Mobile`, `Total_Amt`) VALUES
(1, '2019-07-05', 'aryan', '7390913001', 1720),
(2, '2019-07-05', 'aryan', '7390913001', 10420),
(3, '2019-07-05', 'aryan', '7390913001', 5820);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pcode` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pcode`, `name`, `price`) VALUES
('DA-1002', 'Long Body', 860),
('DA-1003', 'Pillar Cock', 880),
('DA-1005', 'Angular Stop Cock', 760);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ulogin` varchar(20) NOT NULL,
  `upass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ulogin`, `upass`) VALUES
('deepak', 'deepak');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
